

## align
bwa mem ref.fa demo.fq.gz | samtools sort -o align.bam - 

## mpileup
bcftools mpileup -d 100000 -f ref.fa align.bam > mpileup.vcf

## genome coverage
bedtools genomecov -d -ibam align.bam > cov.bg 

## remove dup
sambamba markdup -r align.bam align.rmdup.bam 
bcftools mpileup -d 250 -f ref.fa align.rmdup.bam > mpileup.rmdup.vcf

## output
grep -P "\t311\t" mpileup.vcf cov.bg mpileup.rmdup.vcf

# version
# bwa: 0.7.17-r1188
# samtools: v1.9
# bcftools: v1.9
# bedtools: v2.29.0

## Question
#
# I found out that the read depth in I16 is not equal to the DP in my case. (DP=9953;I16=0,9878,0,28,...)
# 
# The sum of the four number supposed (I think!?) to equal to DP (raw read depth) number, but it is not.
# 
# I have two questions:
# 
# Is there any default filtering that will change the first four numbers in I16? what is it?
# How can I tell the exact the depth for each of the ALT bases? (C, G, A in this case).
# The following are the command and one line of the results:
# 
# $ bcftools mpileup -d 10000 -f ref.fa align.bam > mpileup.vcf
# 
# $ grep -P "\t311\t" mpileup.vcf
# ref     311     .       T       C,G,A   0       .       DP=9953;I16=0,9878,0,28,397088,1.60422e+07,588,12502,592680,3.55608e+07,1680,100800,19953,41405,56,112;QS=0.998521,0.00121707,0.00019111,7.04091e-05;VDB=1.30483e-15;SGB=-0.693054;RPB=0.998703;MQB=1;BQB=1.00562e-18;MQ0F=0      PL      0,255,255,255,255,255,255,255,255,255
# 
# ## bcftools  v1.9

## on biostars: https://www.biostars.org/p/410098/
## on github: https://github.com/samtools/bcftools/issues/1120

