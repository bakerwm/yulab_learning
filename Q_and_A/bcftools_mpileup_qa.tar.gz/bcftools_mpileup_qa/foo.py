

## vcf

import os, sys


# f = 'mpileup.vcf'
f = 'mpileup.rmdup.vcf'

def val(x):
    return x.split('=')[1]

def i16(x):
    k, v = x.split('=')
    n = v.split(',')[:4]
    n = list(map(int, n))
    return str(sum(n))

def des(x):
    tags = x.split(';')
    dp = total = 0
    for i in tags:
        if i.startswith('DP='):
            dp = val(i)
        elif i.startswith('I16='):
            total = i16(i)
        else:
            continue
    return [dp, total]


with open(f) as f1:
    for line in f1:
        line = line.strip()
        if line.startswith('#'):
            continue
        tabs = line.split('\t')
        # fd = tabs[9].split(';')
        j, k = des(tabs[7])
        flag = '1' if j == k else '0'
        print('\t'.join(
            [flag, j, k, line]))

#        break
